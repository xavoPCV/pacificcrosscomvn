<?php
/**
* @package		EasyBlog
* @copyright	Copyright (C) 2010 - 2014 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');


class EasyBlogAvatarDefault
{
	/**
	 * Retrieves the avatar url
	 *
	 * @since	4.0
	 * @access	public
	 * @param	string
	 * @return	
	 */
	public function getAvatar($profile)
	{
		$path 	= JPATH_ROOT . '/' . EB::image()->getAvatarRelativePath() . '/' . $profile->avatar;
		$image 	= EB::image()->getAvatarRelativePath() . '/' . $profile->avatar;
		$app 	= JFactory::getApplication();
		$link 	= $image;
		$default = 'components/com_easyblog/assets/images/default_blogger.png';

		// Check for default overrides
		$overrides = JPATH_ROOT . '/templates/' . $app->getTemplate() . '/html/com_easyblog/assets/images/default_blogger.png';
		$exists = JFile::exists($overrides);

		if (!$profile->avatar) {
			if ($exists) {
				$link 	= 'templates/' . $app->getTemplate() . '/html/com_easyblog/assets/images/default_blogger.png';
			} else {
				$link 	= $default;
			}
		}

		if ($profile->avatar == 'default_blogger.png') {
			$link = $default;
		}

		$link 	= rtrim(JURI::root(), '/') . '/' . $link;

		return $link;
	}
}