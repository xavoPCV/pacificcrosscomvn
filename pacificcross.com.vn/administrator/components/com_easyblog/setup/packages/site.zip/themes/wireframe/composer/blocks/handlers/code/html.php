<pre data-mode="javascript">function foobar() {
    // Write some codes here
}</pre>