<div class="col-3 ar-4x3" data-compare-container>
    <div>
        <b>
            <a href="javascript: void(0);"><img src="/before.jpg"/></a>
        </b>
        <p>Before</p>
    </div>
    <div>
        <b>
            <a href="javascript: void(0);"><img src="/middle.jpg"/></a>
        </b>
        <p>Selected Region</p>
    </div>
    <div>
        <b>
            <a href="javascript: void(0);"><img src="/after.jpg"/></a>
        </b>
        <p>After</p>
    </div>
</div>