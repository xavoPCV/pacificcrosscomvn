<div class="eb-composer-fieldset">
    <div class="eb-composer-fieldset-label">Compare</div>
</div>
