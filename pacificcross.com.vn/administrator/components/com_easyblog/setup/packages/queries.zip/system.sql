/**
* @package  EasyBlog
* @copyright Copyright (C) 2010 - 2014 Stack Ideas Sdn Bhd. All rights reserved.
* @license  GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

CREATE TABLE IF NOT EXISTS `#__easyblog_configs` (
  `name` varchar(255) NOT NULL,
  `params` TEXT NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT = 'Store any configuration in key => params maps';

CREATE TABLE IF NOT EXISTS `#__easyblog_adsense` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `display` varchar(255) NOT NULL DEFAULT 'both',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `#__easyblog_migrate_content` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `component` varchar(255) NOT NULL DEFAULT 'com_content',
  `filename` varchar(255) NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `content_id` (`content_id`),
  KEY `post_id` (`post_id`),
  KEY `session_id` (`session_id`),
  KEY `component_content` (`content_id`, `component`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT = 'Store migrated joomla content id and map with eblog post id.';

CREATE TABLE IF NOT EXISTS `#__easyblog_acl` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `group` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `default` tinyint(1) NOT NULL default '1',
  `description` text NOT NULL,
  `published` tinyint(1) unsigned NOT NULL default '1',
  `ordering` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `easyblog_post_acl_action` (`action`),
  KEY `idx_acl_published` (`published`),
  KEY `idx_acl_published_id` (`published`, `id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_acl_group` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `content_id` bigint(20) unsigned NOT NULL,
  `acl_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `easyblog_post_acl_content_type` (`content_id`,`type`),
  KEY `easyblog_post_acl` (`acl_id`),
  KEY `acl_grp_acl_type` (`acl_id`, `type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_mailq` (
  `id` int(11) NOT NULL auto_increment,
  `mailfrom` varchar(255) NULL,
  `fromname` varchar(255) NULL,
  `recipient` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `created` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `template` varchar(255) default '',
  `data` LONGTEXT default '',
  `param` TEXT default '',
  PRIMARY KEY  (`id`),
  KEY `easyblog_mailq_status` (`status`),
  KEY `idx_mailq_created` (`created`),
  KEY `idx_mailq_statuscreated` (`status`,`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `#__easyblog_meta` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` VARCHAR( 20 ) NOT NULL ,
  `content_id` INT( 11 ) NOT NULL ,
  `title` TEXT NOT NULL,
  `keywords` TEXT NULL ,
  `description` TEXT NULL,
  `indexing` int(3) NOT NULL DEFAULT '1',
  PRIMARY KEY  (`id`),
  KEY `idx_meta_content_type` (`content_id`,`type`)
) ENGINE=MYISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__easyblog_likes` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` VARCHAR( 20 ) NOT NULL ,
  `content_id` INT( 11 ) NOT NULL ,
    `created_by` bigint(20) unsigned NULL DEFAULT 0,
    `created` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `easyblog_content_type` (`type`, `content_id`),
  KEY `easyblog_contentid` (`content_id`),
  KEY `easyblog_createdby` (`created_by`)
) ENGINE=MYISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_feedburner` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) unsigned NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__easyblog_external_groups` (
  `id` bigint(20) NOT NULL auto_increment,
  `source` text NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `external_groups_post_id` (`post_id`),
  KEY `external_groups_group_id` (`group_id`),
  KEY `external_groups_posts` (`group_id`, `post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_xml_wpdata` (
  `id` bigint(20) NOT NULL auto_increment,
  `session_id` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `source` varchar(15) NOT NULL,
  `data` LONGTEXT NOT NULL,
  `comments` LONGTEXT NULL,
  PRIMARY KEY  (`id`),
  KEY `xml_wpdate_session` (`session_id`),
  KEY `xml_wpdate_post_source` (`post_id`, `source`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_acl_filters` (
  `content_id` bigint(20) unsigned NOT NULL,
  `disallow_tags` text NOT NULL,
  `disallow_attributes` text NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_reports` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `obj_id` bigint(20) NOT NULL,
  `obj_type` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `ip` TEXT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `obj_id` (`obj_id`,`created_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;


CREATE TABLE IF NOT EXISTS `#__easyblog_external` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `source` text NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `external_groups_post_id` (`post_id`),
  KEY `external_groups_group_id` (`uid`),
  KEY `external_groups_posts` (`uid`,`post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `updated` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `translator` varchar(255) NOT NULL,
  `progress` int(11) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_mediamanager` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `params` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  FULLTEXT KEY `path` (`path`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__easyblog_uploader_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `path` text NOT NULL,
  `uri` text NOT NULL,
  `raw` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`),
  KEY `idx_uploader_created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `#__easyblog_meta`(`id`,`type`,`content_id`,`keywords`,`description`) VALUES ( 1,'view','1','','') ON DUPLICATE KEY UPDATE `type` = 'view';
INSERT INTO `#__easyblog_meta`(`id`,`type`,`content_id`,`keywords`,`description`) VALUES ( 2,'view','2','','') ON DUPLICATE KEY UPDATE `type` = 'view';
INSERT INTO `#__easyblog_meta`(`id`,`type`,`content_id`,`keywords`,`description`) VALUES ( 3,'view','3','','') ON DUPLICATE KEY UPDATE `type` = 'view';
INSERT INTO `#__easyblog_meta`(`id`,`type`,`content_id`,`keywords`,`description`) VALUES ( 4,'view','4','','') ON DUPLICATE KEY UPDATE `type` = 'view';
INSERT INTO `#__easyblog_meta`(`id`,`type`,`content_id`,`keywords`,`description`) VALUES ( 5,'view','5','','') ON DUPLICATE KEY UPDATE `type` = 'view';
INSERT INTO `#__easyblog_meta`(`id`,`type`,`content_id`,`keywords`,`description`) VALUES ( 6,'view','6','','') ON DUPLICATE KEY UPDATE `type` = 'view';
INSERT INTO `#__easyblog_meta`(`id`,`type`,`content_id`,`keywords`,`description`) VALUES ( 7,'view','7','','') ON DUPLICATE KEY UPDATE `type` = 'view';
INSERT INTO `#__easyblog_meta`(`id`,`type`,`content_id`,`keywords`,`description`) VALUES ( 8,'view','8','','') ON DUPLICATE KEY UPDATE `type` = 'view';

INSERT INTO `#__easyblog_category_acl_item` (`id`, `action`, `description`, `published`, `default`) values ('1', 'view', 'can view the category blog posts.', 1, 1) ON DUPLICATE KEY UPDATE `default` = '1';
INSERT INTO `#__easyblog_category_acl_item` (`id`, `action`, `description`, `published`, `default`) values ('2', 'select', 'can select the category during blog post creation', 1, 1) ON DUPLICATE KEY UPDATE `default` = '1';

