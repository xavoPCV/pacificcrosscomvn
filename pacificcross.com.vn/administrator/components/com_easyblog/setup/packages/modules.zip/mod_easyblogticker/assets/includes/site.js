$(function () {
     // start the ticker
	$('#js-news').ticker();

});

