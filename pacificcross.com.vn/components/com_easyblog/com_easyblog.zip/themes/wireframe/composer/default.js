EasyBlog.require()
.script("composer")
.done(function() {
    
});