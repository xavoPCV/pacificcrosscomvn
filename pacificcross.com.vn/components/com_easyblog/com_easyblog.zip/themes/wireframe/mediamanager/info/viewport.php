<div class="eb-composer-viewport eb-mm-info-preview" data-scrolly="xy">
    <div class="eb-composer-viewport-content" data-scrolly-viewport>
        <div class="ebd-workarea is-standalone eb-mm-workarea" data-eb-mm-workarea>
            <div class="ebd" data-eb-mm-document>
                <?php echo $this->output('site/mediamanager/info/' . $file->type); ?>
            </div>
        </div>
    </div>
</div>
