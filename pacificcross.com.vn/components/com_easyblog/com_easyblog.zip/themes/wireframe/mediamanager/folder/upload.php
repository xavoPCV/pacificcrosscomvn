<?php
/**
* @package      EasyBlog
* @copyright    Copyright (C) 2010 - 2015 Stack Ideas Sdn Bhd. All rights reserved.
* @license      GNU/GPL, see LICENSE.php
* EasyBlog is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');
?>
<?php if ($place->acl->canUploadItem) { ?>
<div class="eb-mm-folder-upload-panel">
    <div class="progress eb-mm-folder-upload-progress">
        <div class="progress-bar eb-mm-folder-upload-progress-bar" style="width: 0%" data-eb-mm-folder-upload-progress-bar></div>
    </div>
    <div class="eb-mm-folder-upload-stat pull-right text-muted" data-eb-mm-folder-upload-stat>
        <span data-eb-mm-folder-upload-completed>0</span>/<span data-eb-mm-folder-upload-total>0</span>
    </div>
    <div class="eb-mm-folder-upload-current-file">
        <div><b><?php echo JText::_('COM_EASYBLOG_MM_UPLOADING');?></b>...</div>
        <div data-eb-mm-folder-upload-current-file></div>
    </div>
</div>
<?php } ?>