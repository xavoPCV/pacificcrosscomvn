<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

if ( JRequest::getVar('layoutv') == 1 ) {
    include_once __DIR__.'/view2.php';
}else {
    include_once __DIR__.'/view1.php';
}
 

