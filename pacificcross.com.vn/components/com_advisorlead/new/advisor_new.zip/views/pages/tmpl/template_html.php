<script type="text/javascript" src="<?php echo ASSETS_URL ?>/js/page_templates.js"></script>
<?php echo $this->template_html; ?>
