<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_countup
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

$document = JFactory::getDocument();

JHtml::_('bootstrap.framework');



?>
<link rel="stylesheet" href="https://www.dropifi.com/public/clientmessenger/bootstrap/css/bootstrap.min.css">

  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<style>
    .a12{
        border-radius: 3px 0px 0px 3px; clear: none; clip: auto; counter-increment: none; counter-reset: none; direction: inherit; float: none; font-family: inherit; font-style: inherit; font-variant: normal; font-weight: inherit; height: auto; letter-spacing: normal; line-height: inherit; list-style: inherit inside none; max-height: none; max-width: none; opacity: 1; padding: 0px; table-layout: auto; text-decoration: inherit; text-transform: none; unicode-bidi: normal; vertical-align: baseline; visibility: inherit; white-space: normal; width: 30px; word-spacing: normal; display: inline-block; margin: 0px; cursor: pointer; box-sizing: content-box; color: rgb(255, 255, 255); overflow: hidden; position: fixed; z-index: 999999999; font-size: 14px; text-align: center; border-width: 1px 0px 1px 1px; border-style: solid; border-color: rgb(255, 255, 255); box-shadow: rgb(148, 136, 136) 0px 0px 3px 0px, white 0px 0px 3px 0px; min-height: 100px; min-width: 10px; right: 0px; top: 199.15px; background: none 0px 0px repeat scroll rgb(222, 20, 37);
    }
    .a13{
        clear: none; clip: auto; color: inherit; counter-increment: none; counter-reset: none; cursor: auto; direction: inherit; display: inline; float: none; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: normal; font-weight: inherit; letter-spacing: normal; line-height: inherit; max-height: none; max-width: none; opacity: 1; table-layout: auto; text-align: inherit; text-decoration: inherit; text-transform: none; unicode-bidi: normal; vertical-align: baseline; visibility: visible; white-space: normal; word-spacing: normal; border-collapse: collapse; border-spacing: 0px; height: 386px;  margin: 0px; list-style: none outside none; outline: none medium; overflow: hidden; position: fixed; width: 300px; z-index: 2147483645; border: 3px solid rgb(255, 255, 255); border-radius: 5px; box-shadow: rgb(148, 136, 136) 0px 0px 6px 0px, white 0px 0px 10px 0px; padding: 0px; box-sizing: content-box; background-image: none; background-attachment: scroll; background-color: white; background-position: 0px 0px; background-repeat: repeat;bottom: 10px;right: 0px;
    }
    .a14{
        border: medium none black; border-radius: 0px; clear: none; clip: auto; counter-increment: none; counter-reset: none; direction: inherit; float: none; font-family: inherit; font-style: inherit; font-variant: normal; font-weight: inherit; height: auto; letter-spacing: normal; line-height: inherit; list-style: inherit inside none; margin: 0px; max-height: none; max-width: none; opacity: 1; overflow: visible; position: static; table-layout: auto; text-decoration: inherit; text-transform: none; unicode-bidi: normal; vertical-align: baseline; visibility: inherit; white-space: normal; width: auto; word-spacing: normal; z-index: auto; color: rgb(255, 255, 255); padding: 5px 10px; box-shadow: rgb(148, 136, 136) 0px 0px 2px 0px, rgb(26, 135, 199) 0px 0px 2px 0px; text-align: justify; font-size: 14px; display: block; cursor: move; background: rgb(222, 20, 37);
    }
    #captchaResult {
    display: inline-block;
    width: 50px;
}
</style>
<script>
  function showhidew(a){
      if(a==1){
          jQuery('#dropifiContactTab').hide();
          jQuery('#dropifiContactContent').show();
      }else{
           jQuery('#dropifiContactTab').show();
           jQuery('#dropifiContactContent').hide();
      }
  }
   jQuery(function() {
    jQuery( "#dropifiContactContent" ).draggable({ handle: "p#dropifiTextContent" });
    
    jQuery( "div, p" ).disableSelection();
  });
  </script>
 








  <div class="a12" id="dropifiContactTab" onclick="showhidew(1);">
     <div id="dropifi2012_version_inner_label" style="width:30px;margin-right:auto;margin-left:auto;padding-left:8px;"><img id="dropifi_widget_v1_imageText" style="padding:0px;display:inherit !important;border:0px;margin-top:5px;margin-bottom:8px;box-shadow: 0 0 0 transparent;cursor:pointer" src="https://9e63623416e15ee5e59b-59ae2e77d7e5c984fda3946e71d01e47.ssl.cf5.rackcdn.com/dropifi/tab_text.png?v=1450228686948"></div></div>
 
 
 
 
 <div class="a13" style="display: none;" id="dropifiContactContent"  >
     
     
     <div class="a14" style="" id="dropifiContentBar">
         <p style="border: medium none black; border-radius: 0px; clear: none; clip: auto; color: rgb(255, 255, 255); counter-increment: none; counter-reset: none; direction: inherit; float: none; font-family: inherit; font-size: 14px; font-style: inherit; font-variant: normal; font-weight: normal; height: auto; letter-spacing: normal; line-height: inherit; list-style: inherit inside none; margin: 0px; max-height: none; max-width: none; opacity: 1; padding: 0px 5px 0px 0px; position: static; table-layout: auto; text-align: left; text-decoration: inherit; text-transform: none; unicode-bidi: normal; vertical-align: baseline; visibility: inherit; white-space: normal; word-spacing: normal; z-index: auto; overflow: hidden; cursor: move; display: inline-block; width: 90%; background-image: none; background-attachment: scroll; background-color: transparent; background-position: 0px 0px; background-repeat: repeat;" id="dropifiTextContent">Contact Us</p><p style="background-attachment:scroll;background-color:transparent;background-image:none;background-position:0 0;background-repeat:repeat;border-color:black;border-radius:0;border-style:none;border-width:medium;clear:none;clip:auto;color:inherit;counter-increment:none;counter-reset:none;cursor:auto;direction:inherit;display:inline;float:none;font-family:inherit;font-size:inherit;font-style:inherit;font-variant:normal;font-weight:inherit;height:auto;letter-spacing:normal;line-height:inherit;list-style-image:none;list-style-position:inside;list-style-type:inherit;margin:0;max-height:none;max-width:none;opacity:1;overflow:visible;padding:0;position:static;table-layout:auto;text-align:inherit;text-decoration:inherit;text-transform:none;unicode-bidi:normal;vertical-align:baseline;visibility:inherit;white-space:normal;width:auto;word-spacing:normal;z-index:auto;float:right;cursor:pointer;position:relative;top:0px;margin-right:-5px;display:block"><img style="background-attachment:scroll;background-color:transparent;background-image:none;background-position:0 0;background-repeat:repeat;border-color:black;border-radius:0;border-style:none;border-width:medium;clear:none;clip:auto;color:inherit;counter-increment:none;counter-reset:none;cursor:auto;direction:inherit;display:inline;float:none;font-family:inherit;font-size:inherit;font-style:inherit;font-variant:normal;font-weight:inherit;height:auto;letter-spacing:normal;line-height:inherit;list-style-image:none;list-style-position:inside;list-style-type:inherit;margin:0;max-height:none;max-width:none;opacity:1;overflow:visible;padding:0;position:static;table-layout:auto;text-align:inherit;text-decoration:inherit;text-transform:none;unicode-bidi:normal;vertical-align:baseline;visibility:inherit;white-space:normal;width:auto;word-spacing:normal;z-index:auto;cursor:pointer;width:20px;" src="https://api.dropifi.com/widget/images/close_button_circle.png" id="dropifiCloseBar" onclick="showhidew(2);"></p></div>
        <div id="dropifiIframeContainer" style="height: 270px; background-image: url(&quot;&quot;);" >
            
   <div id="contentInner" style="font-family:SansSerif">
		<form style="font-family:SansSerif" id="fileupload" name="fileupload" action="index.php" method="POST" enctype="multipart/form-data">
			<div id="formContent">
                            <p id="header"> </p>
                            <p class="input-group"><span class="input-group-addon glyphicon glyphicon-envelope"></span>
                                <input id="widgetField_email" type="email" name="cs.email" class="form-control" placeholder="your email" required=""><span style="display:none" id="widgetError_email">your email is required</span> </p>
                           
                            <p class="input-group">
                                <span class="input-group-addon glyphicon glyphicon-pencil"></span>
                                <select id="widgetField_subject" name="cs.subject" class="form-control" required="">
                                     <option value="Select Type Support" id="optCustomer Support">Select Type Support</option>
                                    <?php
                                    
                                    $grouptype = explode('|', $grouptype);
                                    foreach ($grouptype as $r) { ?>
                                         <option value="<?php echo $r ?>" ><?php echo $r ?></option>
                                    <?php } ?>
                                   
                                
                                  
                                </select>
                                <span style="display:none" id="widgetError_subject">the subject of the message is required</span> 
                            
                            </p><p>
                                <textarea id="widgetField_message" name="cs.message" rows="3" class="form-control" cols="20" placeholder="how can we help you?" required=""></textarea>
                                <span style="display:none" id="widgetError_message">your message is required</span> 
                            </p>
                           
                            <p><span id="fileContent"><input id="widgetField_attachment" name="uploadfile" type="file"></span> <span id="clearfile" title="remove file">x</span></p>
                            <input type="hidden" id="attachmentId" name="cs.attachmentId" value="bc73c6108299">
                            <input type="hidden" id="fileType" name="fileType" value="">
                            <p style="    float: left;"><span>What's the result of </span><span id="captchaText"><?php $a = rand(1,10);echo $a ?> + <?php $b = rand(1,10);echo $b  ?> = </span>
                           <input id="captchaResult" name="cs.captchaResult" type="text" class="form-control" required=""></p>
                           <input type="hidden" id="captchaCode" name="cs.captchaCode" value="<?php echo base64_encode($a+$b); ?>">
                           <input type="hidden" id="url" name="mail_resent" value="<?php echo $email ?>">
                           <input type="hidden"  name="option" value="com_contact">
                           <input type="hidden"  name="task" value="savewcontact">
                           
                            <?php echo JHtml::_('form.token'); ?>
                          <p class="dropifi_submit_input"> <input id="sendMail" style="background-color:#0D0B0B;color:#ffffff;border-color:#0D0B0B;    width: 100%;" class="btn btn-primary" name="sendMail" value="Send Message" type="submit"> </p></div>
			
		</form>
	</div>
    
    
    </div></div>
  
  
   